# plugin.video.freplay
FReplay : an XBMC addon

Addon for Kodi that retrieves the replay info from different french channels
